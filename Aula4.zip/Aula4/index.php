<?php

//Função sem retorno e sem parâmetro

function calcularSoma(){
    $resultado = 4 + 4;
    echo $resultado;
}
//chamada da função
//calcularSoma();



//função sem retorno e com parâmetro
function calcularPreco($quantidade, $preco)
{
    $valor = $quantidade * $preco;
    echo $valor;
}
//calcularPreco(4, 25);



//função com parâmetros e com retorno
function calcularSubtracao($n1, $n2)
{
    return $n1 - $n2;
}

//escreva a chamada aqui
//echo (calcularSubtracao(10, 1));

/*outra forma
$resultado = calcularSubtracao(10,5);
echo $resultado;*/


function ePar($numero){
    if($numero % 2 == 0){
        return true;
    }
    return false;
}
 
if(ePar(15))
echo "é par";
else echo "é impar";

//Operador Ternário fazendo a mesma coisa de cima 
//echo ePar(15)?"é par":"é ímpar";