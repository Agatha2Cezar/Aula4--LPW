<?php
    //echo  "seu nome é ".$_POST["nome"];
    
    //Outra forma de fazer:
    $nome = $_POST["nome"];
    echo "Seu nome é $nome";

    echo "</br>";

    $curso = $_POST["curso"];
    echo "Seu curso é $curso";